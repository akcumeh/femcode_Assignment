data: The server time is: Thu, 14 Nov 2019 08:13:02 -0500

